// app/notebook/ResponseCard.tsx
"use client";

export default function ResponseCard({ resp }: { resp: any }) {
  return (
    <div className="bg-white rounded-xl shadow p-3">
      <div className="text-xs text-gray-500 mb-1">
        {resp.authorType === "ai" ? "AI" : "You"} •{" "}
        {new Date(resp.createdAt).toLocaleString()}
      </div>
      <div
        className="markdown"
        dangerouslySetInnerHTML={{ __html: resp.contentHtml || resp.content }}
      />
    </div>
  );
}
